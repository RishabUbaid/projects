

function App() {
  return(
    <>
    <h1 className="texfont-bold font-bold ">W. </h1>
    </>
  )
}
export default App
