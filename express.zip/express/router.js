// import { Router } from "express";

// import  * as th from "./request-handlers/todo.handler.js";

// const router = Router();

// router.route("/set-text").post(rh.setText);
// router.route("/chumma").get(customMW,(req, res) => {
//     return res.status(200).json("this is your request handler!")
// })

// export default router;

// function customMW(req, res, next){
//     let { number } = req.body;
//     console.log("middle ware");
//     if(number%2 ==0 ){
//         return res.status(200).json("Response from middleware")
//     }
//     next();
// }
import { Router } from "express";

import * as rh from "./request-handlers/todo.handler.js";
import * as user from "./request-handlers/user.handler.js";

const router = Router();

router.route("/register").post(user.register);
router.route("/login").post(user.login);

export default router;