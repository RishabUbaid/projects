import bcrypt from "bcrypt";
import

import userModel from "../schema/user.schema.js";

export async function register(req, res) {
    try {
        let { username, email, password } = req.body;
        let hashedPassword = await bcrypt.hash(password, 10);
        await userModel.create({
            username,
            email,
            password: hashedPassword
        })
        return res.status(201).json({
            msg: "Registration successful!..."
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: "Error occured"
        })
    }
}